package com.akasha.terminal.utils

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.akasha.terminal.ai.AIProvider
import com.akasha.terminal.ai.AIProviderConfig
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "akasha_settings")

class PreferencesManager(private val context: Context) {

    companion object {
        val AI_PROVIDER = stringPreferencesKey("ai_provider")
        val AI_API_KEY = stringPreferencesKey("ai_api_key")
        val AI_MODEL = stringPreferencesKey("ai_model")
        val AI_BASE_URL = stringPreferencesKey("ai_base_url")
        val ROOT_ENABLED = booleanPreferencesKey("root_enabled")
        val OVERLAY_ENABLED = booleanPreferencesKey("overlay_enabled")
        val SAVE_HISTORY = booleanPreferencesKey("save_history")
        val FIRST_LAUNCH = booleanPreferencesKey("first_launch")
    }

    val aiProviderConfig: Flow<AIProviderConfig> = context.dataStore.data.map { prefs ->
        val provider = try {
            AIProvider.valueOf(prefs[AI_PROVIDER] ?: "GEMINI")
        } catch (e: Exception) { AIProvider.GEMINI }

        AIProviderConfig(
            provider = provider,
            apiKey = prefs[AI_API_KEY] ?: "",
            modelName = prefs[AI_MODEL] ?: "",
            baseUrl = prefs[AI_BASE_URL] ?: "",
            isLocal = provider == AIProvider.LOCAL_OLLAMA
        )
    }

    val isRootEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[ROOT_ENABLED] ?: false
    }

    val isOverlayEnabled: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[OVERLAY_ENABLED] ?: true
    }

    val isFirstLaunch: Flow<Boolean> = context.dataStore.data.map { prefs ->
        prefs[FIRST_LAUNCH] ?: true
    }

    suspend fun saveAIConfig(config: AIProviderConfig) {
        context.dataStore.edit { prefs ->
            prefs[AI_PROVIDER] = config.provider.name
            prefs[AI_API_KEY] = config.apiKey
            prefs[AI_MODEL] = config.modelName
            prefs[AI_BASE_URL] = config.baseUrl
        }
    }

    suspend fun setRootEnabled(enabled: Boolean) {
        context.dataStore.edit { prefs -> prefs[ROOT_ENABLED] = enabled }
    }

    suspend fun setFirstLaunchDone() {
        context.dataStore.edit { prefs -> prefs[FIRST_LAUNCH] = false }
    }
}
