package com.akasha.terminal.ai

import com.google.gson.annotations.SerializedName

// ─── Risk level untuk setiap step ───────────────────────────────────────────
enum class RiskLevel {
    SAFE,       // ✅ Aman total
    CAUTION,    // ⚠️ Butuh perhatian
    SENSITIVE,  // 🔐 Akses data sensitif
    DANGEROUS   // 🚨 Berbahaya / risiko tinggi
}

// ─── Tipe action yang bisa dieksekusi ────────────────────────────────────────
enum class ActionType {
    OPEN_APP,
    CLICK,
    LONG_CLICK,
    INPUT_TEXT,
    SCROLL,
    SWIPE,
    WAIT,
    PRESS_BACK,
    PRESS_HOME,
    TAKE_SCREENSHOT,
    OPEN_URL,
    COPY_TEXT,
    PASTE_TEXT,
    REQUEST_INPUT,      // pause, minta input dari user (OTP, password, dll)
    SHELL_COMMAND,      // root only
    READ_CONTACTS,
    WRITE_CONTACTS,
    READ_FILE,
    WRITE_FILE,
    OPEN_SETTINGS,
    CONDITIONAL         // if/else logic
}

// ─── Satu step dalam alur otomatisasi ────────────────────────────────────────
data class AutomationStep(
    val id: Int,
    val title: String,
    val description: String,
    val actionType: ActionType,
    val params: Map<String, String> = emptyMap(),
    val riskLevel: RiskLevel = RiskLevel.SAFE,
    val warningMessage: String? = null,
    val requiresRoot: Boolean = false,
    val requiresUserInput: Boolean = false,
    val userInputLabel: String? = null,   // label buat dialog input (e.g. "Masukkan OTP")
    val userInputHint: String? = null,
    val isPassword: Boolean = false,
    val canSkip: Boolean = false
)

// ─── Hasil parsing dari AI ───────────────────────────────────────────────────
data class ParsedAutomation(
    val title: String,
    val summary: String,
    val steps: List<AutomationStep>,
    val overallRisk: RiskLevel,
    val globalWarnings: List<String> = emptyList(),
    val requiresRoot: Boolean = false,
    val estimatedDuration: String = "< 1 menit"
)

// ─── Status eksekusi ─────────────────────────────────────────────────────────
sealed class ExecutionState {
    object Idle : ExecutionState()
    object Parsing : ExecutionState()
    data class Preview(val automation: ParsedAutomation) : ExecutionState()
    data class WaitingConfirmation(val automation: ParsedAutomation) : ExecutionState()
    data class Running(
        val automation: ParsedAutomation,
        val currentStepIndex: Int,
        val completedSteps: List<Int>
    ) : ExecutionState()
    data class WaitingInput(
        val automation: ParsedAutomation,
        val stepIndex: Int,
        val label: String,
        val hint: String?,
        val isPassword: Boolean
    ) : ExecutionState()
    data class Completed(val automation: ParsedAutomation, val success: Boolean, val message: String) : ExecutionState()
    data class Error(val message: String) : ExecutionState()
}

// ─── Konfigurasi AI provider ──────────────────────────────────────────────────
data class AIProviderConfig(
    val provider: AIProvider,
    val apiKey: String = "",
    val modelName: String = "",
    val baseUrl: String = "",
    val isLocal: Boolean = false,
    val localModelPath: String = ""
)

enum class AIProvider {
    GEMINI,
    CLAUDE,
    DEEPSEEK,
    OPENAI_COMPATIBLE,  // Untuk provider custom yang pakai OpenAI format
    LOCAL_OLLAMA        // AI lokal via Ollama
}
