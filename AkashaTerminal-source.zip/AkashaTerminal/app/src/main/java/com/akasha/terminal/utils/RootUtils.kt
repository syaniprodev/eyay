package com.akasha.terminal.utils

import android.content.Context
import com.scottyab.rootbeer.RootBeer
import java.io.File

object RootUtils {

    fun isRooted(context: Context): Boolean {
        return try {
            RootBeer(context).isRooted
        } catch (e: Exception) {
            checkManually()
        }
    }

    private fun checkManually(): Boolean {
        // Cek keberadaan binary su
        val suPaths = listOf(
            "/system/bin/su", "/system/xbin/su",
            "/sbin/su", "/su/bin/su",
            "/data/local/xbin/su", "/data/local/bin/su",
            "/system/sd/xbin/su", "/system/bin/failsafe/su",
            "/data/local/su", "/su/bin"
        )
        return suPaths.any { File(it).exists() }
    }

    fun canExecuteRoot(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val output = process.inputStream.bufferedReader().readText()
            process.waitFor()
            output.contains("uid=0") // uid 0 = root
        } catch (e: Exception) {
            false
        }
    }
}

object RiskColorUtil {
    fun getColor(risk: String): Int {
        return when (risk) {
            "SAFE" -> 0xFF4ADE80.toInt()
            "CAUTION" -> 0xFFFBBF24.toInt()
            "SENSITIVE" -> 0xFFFB923C.toInt()
            "DANGEROUS" -> 0xFFEF4444.toInt()
            else -> 0xFF4ADE80.toInt()
        }
    }

    fun getEmoji(risk: String): String {
        return when (risk) {
            "SAFE" -> "✅"
            "CAUTION" -> "⚠️"
            "SENSITIVE" -> "🔐"
            "DANGEROUS" -> "🚨"
            else -> "●"
        }
    }
}
