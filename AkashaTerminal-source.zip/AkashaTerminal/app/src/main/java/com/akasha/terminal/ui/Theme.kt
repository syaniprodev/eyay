package com.akasha.terminal.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// ─── Palette Akasha Terminal ──────────────────────────────────────────────────
// Dark terminal aesthetic: deep navy bg, cyan accent, slate text
val AkashaBackground = Color(0xFF0A0F1E)       // Deep navy, almost black
val AkashaSurface = Color(0xFF111827)           // Slightly lighter navy
val AkashaSurfaceVariant = Color(0xFF1E293B)    // Card/input background
val AkashaAccent = Color(0xFF38BDF8)            // Sky blue - primary accent
val AkashaAccentDim = Color(0xFF0EA5E9)         // Slightly deeper accent
val AkashaText = Color(0xFFF1F5F9)             // Off-white
val AkashaTextSecondary = Color(0xFF94A3B8)    // Slate gray
val AkashaTextMuted = Color(0xFF475569)        // Muted

// Risk colors
val ColorSafe = Color(0xFF4ADE80)              // Green
val ColorCaution = Color(0xFFFBBF24)           // Amber
val ColorSensitive = Color(0xFFFB923C)         // Orange
val ColorDangerous = Color(0xFFEF4444)         // Red

private val DarkColorScheme = darkColorScheme(
    primary = AkashaAccent,
    secondary = AkashaAccentDim,
    tertiary = ColorSafe,
    background = AkashaBackground,
    surface = AkashaSurface,
    surfaceVariant = AkashaSurfaceVariant,
    onPrimary = AkashaBackground,
    onSecondary = AkashaBackground,
    onBackground = AkashaText,
    onSurface = AkashaText,
    onSurfaceVariant = AkashaTextSecondary,
    error = ColorDangerous,
    outline = AkashaTextMuted
)

@Composable
fun AkashaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
