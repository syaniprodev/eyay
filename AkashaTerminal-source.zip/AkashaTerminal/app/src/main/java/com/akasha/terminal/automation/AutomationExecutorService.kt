package com.akasha.terminal.automation

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.akasha.terminal.ai.AutomationStep
import com.akasha.terminal.ai.ParsedAutomation
import com.akasha.terminal.overlay.OverlayService
import com.akasha.terminal.ui.MainActivity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class AutomationExecutorService : Service() {

    companion object {
        const val NOTIF_CHANNEL_ID = "akasha_execution"
        const val NOTIF_ID = 1001

        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val ACTION_PROVIDE_INPUT = "ACTION_PROVIDE_INPUT"
        const val EXTRA_INPUT_VALUE = "EXTRA_INPUT_VALUE"
    }

    private val binder = ExecutorBinder()
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    // State flow buat observer di UI
    private val _state = MutableStateFlow<ExecutorState>(ExecutorState.Idle)
    val state: StateFlow<ExecutorState> = _state

    private var currentAutomation: ParsedAutomation? = null
    private var currentStepIndex = 0
    private var pendingInputContinuation: CancellableContinuation<String>? = null

    inner class ExecutorBinder : Binder() {
        fun getService() = this@AutomationExecutorService
    }

    override fun onBind(intent: Intent): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopExecution()
            ACTION_PROVIDE_INPUT -> {
                val value = intent.getStringExtra(EXTRA_INPUT_VALUE) ?: ""
                pendingInputContinuation?.resume(value) {}
            }
        }
        return START_STICKY
    }

    // ─── Start eksekusi automation ────────────────────────────────────────────
    fun startExecution(automation: ParsedAutomation) {
        currentAutomation = automation
        currentStepIndex = 0

        startForeground(NOTIF_ID, buildNotification("Memulai: ${automation.title}"))

        scope.launch {
            executeAutomation(automation)
        }
    }

    private suspend fun executeAutomation(automation: ParsedAutomation) {
        val accessibility = AkashaAccessibilityService.instance
        if (accessibility == null) {
            _state.value = ExecutorState.Failed("Accessibility Service tidak aktif. Aktifkan dulu di Settings.")
            return
        }

        val completedSteps = mutableListOf<Int>()
        val failedSteps = mutableListOf<Int>()

        for ((index, step) in automation.steps.withIndex()) {
            currentStepIndex = index
            _state.value = ExecutorState.RunningStep(automation, index, completedSteps.toList())

            // Update overlay
            updateOverlay(step, index + 1, automation.steps.size, automation)

            // Update notifikasi
            updateNotification("Step ${index + 1}/${automation.steps.size}: ${step.title}")

            // Kalau butuh input dari user → pause dan tunggu
            var userInput: String? = null
            if (step.requiresUserInput) {
                _state.value = ExecutorState.WaitingInput(
                    automation, index,
                    step.userInputLabel ?: "Masukkan input",
                    step.userInputHint,
                    step.isPassword
                )

                // Tampilkan dialog input lewat overlay
                showInputViaOverlay(step)

                // Suspend sampai user ngisi
                userInput = suspendCancellableCoroutine { cont ->
                    pendingInputContinuation = cont
                }
            }

            // Eksekusi step
            val result = accessibility.executeStep(step, userInput)

            when (result) {
                is StepResult.Success, is StepResult.SuccessWithData -> {
                    completedSteps.add(step.id)
                }
                is StepResult.NeedsInput -> {
                    // AI tidak mark requiresUserInput tapi runtime detect perlu input
                    _state.value = ExecutorState.WaitingInput(
                        automation, index,
                        result.label, result.hint, result.isPassword
                    )
                    userInput = suspendCancellableCoroutine { cont ->
                        pendingInputContinuation = cont
                    }
                    // Retry step dengan input
                    val retryResult = accessibility.executeStep(step, userInput)
                    if (retryResult is StepResult.Success || retryResult is StepResult.SuccessWithData) {
                        completedSteps.add(step.id)
                    } else {
                        failedSteps.add(step.id)
                    }
                }
                is StepResult.Failure -> {
                    failedSteps.add(step.id)
                    if (!step.canSkip) {
                        _state.value = ExecutorState.Failed(
                            "Step ${index + 1} gagal: ${result.error}"
                        )
                        updateOverlay(null, index + 1, automation.steps.size, automation)
                        return
                    }
                }
            }
        }

        val success = failedSteps.isEmpty()
        _state.value = ExecutorState.Completed(automation, success,
            if (success) "Semua step berhasil dijalankan!"
            else "${failedSteps.size} step gagal, ${completedSteps.size} berhasil"
        )

        updateNotification(if (success) "✅ Selesai: ${automation.title}" else "⚠️ Selesai dengan error")
        updateOverlay(null, automation.steps.size, automation.steps.size, automation)
    }

    // ─── Provide input dari user ──────────────────────────────────────────────
    fun provideInput(value: String) {
        pendingInputContinuation?.resume(value) {}
        pendingInputContinuation = null
    }

    // ─── Stop eksekusi ────────────────────────────────────────────────────────
    fun stopExecution() {
        scope.coroutineContext.cancelChildren()
        pendingInputContinuation?.cancel()
        pendingInputContinuation = null
        _state.value = ExecutorState.Stopped
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ─── Update overlay service ───────────────────────────────────────────────
    private fun updateOverlay(
        currentStep: AutomationStep?,
        stepNumber: Int,
        totalSteps: Int,
        automation: ParsedAutomation
    ) {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_UPDATE
            putExtra(OverlayService.EXTRA_STEP_NUMBER, stepNumber)
            putExtra(OverlayService.EXTRA_TOTAL_STEPS, totalSteps)
            putExtra(OverlayService.EXTRA_STEP_TITLE, currentStep?.title ?: "Selesai")
            putExtra(OverlayService.EXTRA_STEP_DESCRIPTION, currentStep?.description ?: "")
            putExtra(OverlayService.EXTRA_STEP_RISK, currentStep?.riskLevel?.name ?: "SAFE")
            putExtra(OverlayService.EXTRA_WARNING, currentStep?.warningMessage ?: "")
            putExtra(OverlayService.EXTRA_AUTOMATION_TITLE, automation.title)
        }
        startService(intent)
    }

    private fun showInputViaOverlay(step: AutomationStep) {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_SHOW_INPUT
            putExtra(OverlayService.EXTRA_INPUT_LABEL, step.userInputLabel ?: "Masukkan input")
            putExtra(OverlayService.EXTRA_INPUT_HINT, step.userInputHint ?: "")
            putExtra(OverlayService.EXTRA_IS_PASSWORD, step.isPassword)
        }
        startService(intent)
    }

    // ─── Notification ─────────────────────────────────────────────────────────
    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            NOTIF_CHANNEL_ID,
            "Akasha Terminal - Eksekusi",
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Notifikasi saat Akasha Terminal menjalankan otomatisasi"
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(text: String): Notification {
        val stopIntent = Intent(this, AutomationExecutorService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 0, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val openIntent = Intent(this, MainActivity::class.java)
        val openPendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, NOTIF_CHANNEL_ID)
            .setContentTitle("Akasha Terminal")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(openPendingIntent)
            .addAction(android.R.drawable.ic_delete, "Stop", stopPendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotification(text: String) {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}

// ─── State eksekutor ──────────────────────────────────────────────────────────
sealed class ExecutorState {
    object Idle : ExecutorState()
    object Stopped : ExecutorState()
    data class RunningStep(
        val automation: ParsedAutomation,
        val stepIndex: Int,
        val completedSteps: List<Int>
    ) : ExecutorState()
    data class WaitingInput(
        val automation: ParsedAutomation,
        val stepIndex: Int,
        val label: String,
        val hint: String?,
        val isPassword: Boolean
    ) : ExecutorState()
    data class Completed(
        val automation: ParsedAutomation,
        val success: Boolean,
        val message: String
    ) : ExecutorState()
    data class Failed(val error: String) : ExecutorState()
}
