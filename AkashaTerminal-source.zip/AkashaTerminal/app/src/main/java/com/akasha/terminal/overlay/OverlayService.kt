package com.akasha.terminal.overlay

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import com.akasha.terminal.automation.AutomationExecutorService
import com.akasha.terminal.utils.RiskColorUtil

class OverlayService : Service() {

    companion object {
        const val ACTION_UPDATE = "ACTION_UPDATE"
        const val ACTION_SHOW_INPUT = "ACTION_SHOW_INPUT"
        const val ACTION_HIDE = "ACTION_HIDE"
        const val ACTION_SHOW = "ACTION_SHOW"

        const val EXTRA_STEP_NUMBER = "EXTRA_STEP_NUMBER"
        const val EXTRA_TOTAL_STEPS = "EXTRA_TOTAL_STEPS"
        const val EXTRA_STEP_TITLE = "EXTRA_STEP_TITLE"
        const val EXTRA_STEP_DESCRIPTION = "EXTRA_STEP_DESCRIPTION"
        const val EXTRA_STEP_RISK = "EXTRA_STEP_RISK"
        const val EXTRA_WARNING = "EXTRA_WARNING"
        const val EXTRA_AUTOMATION_TITLE = "EXTRA_AUTOMATION_TITLE"
        const val EXTRA_INPUT_LABEL = "EXTRA_INPUT_LABEL"
        const val EXTRA_INPUT_HINT = "EXTRA_INPUT_HINT"
        const val EXTRA_IS_PASSWORD = "EXTRA_IS_PASSWORD"
    }

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var inputView: View? = null
    private var isExpanded = false

    // State terakhir
    private var lastStepNumber = 0
    private var lastTotalSteps = 0
    private var lastStepTitle = ""
    private var lastStepDesc = ""
    private var lastRisk = "SAFE"
    private var lastWarning = ""
    private var lastTitle = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_UPDATE -> {
                lastStepNumber = intent.getIntExtra(EXTRA_STEP_NUMBER, 0)
                lastTotalSteps = intent.getIntExtra(EXTRA_TOTAL_STEPS, 0)
                lastStepTitle = intent.getStringExtra(EXTRA_STEP_TITLE) ?: ""
                lastStepDesc = intent.getStringExtra(EXTRA_STEP_DESCRIPTION) ?: ""
                lastRisk = intent.getStringExtra(EXTRA_STEP_RISK) ?: "SAFE"
                lastWarning = intent.getStringExtra(EXTRA_WARNING) ?: ""
                lastTitle = intent.getStringExtra(EXTRA_AUTOMATION_TITLE) ?: ""

                if (overlayView == null) showOverlay() else updateOverlayContent()
            }
            ACTION_SHOW_INPUT -> {
                val label = intent.getStringExtra(EXTRA_INPUT_LABEL) ?: "Input"
                val hint = intent.getStringExtra(EXTRA_INPUT_HINT) ?: ""
                val isPassword = intent.getBooleanExtra(EXTRA_IS_PASSWORD, false)
                showInputOverlay(label, hint, isPassword)
            }
            ACTION_HIDE -> hideOverlay()
            ACTION_SHOW -> if (overlayView == null) showOverlay() else overlayView?.visibility = View.VISIBLE
        }
        return START_STICKY
    }

    // ─── Buat dan tampilkan overlay utama ─────────────────────────────────────
    private fun showOverlay() {
        if (overlayView != null) return

        // Buat view programmatically (tanpa inflate, biar standalone)
        val container = buildOverlayView()
        overlayView = container

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 16
            y = 120
        }

        // Drag to move
        var initialX = 0
        var initialY = 0
        var touchX = 0f
        var touchY = 0f

        container.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX - (event.rawX - touchX).toInt()
                    params.y = initialY + (event.rawY - touchY).toInt()
                    windowManager.updateViewLayout(container, params)
                    true
                }
                else -> false
            }
        }

        windowManager.addView(container, params)
        updateOverlayContent()
    }

    // ─── Build overlay view secara programmatic ───────────────────────────────
    private fun buildOverlayView(): LinearLayout {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, 0)
        }

        // ── Mini bar (selalu terlihat) ──────────────────────────────────────
        val miniBar = LinearLayout(this).apply {
            id = View.generateViewId()
            tag = "mini_bar"
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(0xE6111827.toInt()) // dark navy 90% opacity
            // Rounded corners via background drawable (set programmatically)
        }

        // Dot indikator risk
        val riskDot = TextView(this).apply {
            id = View.generateViewId()
            tag = "risk_dot"
            text = "●"
            textSize = 10f
            setTextColor(0xFF4ADE80.toInt()) // green default
        }

        // Teks "Step X/Y"
        val stepText = TextView(this).apply {
            id = View.generateViewId()
            tag = "step_text"
            text = "Memulai..."
            textSize = 12f
            setTextColor(0xFFE2E8F0.toInt())
            setPadding(6, 0, 6, 0)
        }

        // Tombol ⓘ
        val infoBtn = TextView(this).apply {
            id = View.generateViewId()
            tag = "info_btn"
            text = " ⓘ "
            textSize = 14f
            setTextColor(0xFF94A3B8.toInt())
            isClickable = true
            isFocusable = true
        }

        miniBar.addView(riskDot)
        miniBar.addView(stepText)
        miniBar.addView(infoBtn)

        // ── Panel detail (collapsed by default) ───────────────────────────
        val detailPanel = LinearLayout(this).apply {
            id = View.generateViewId()
            tag = "detail_panel"
            orientation = LinearLayout.VERTICAL
            setPadding(14, 10, 14, 12)
            setBackgroundColor(0xF0111827.toInt())
            visibility = View.GONE
        }

        val titleText = TextView(this).apply {
            tag = "detail_title"
            textSize = 11f
            setTextColor(0xFF64748B.toInt()) // slate
            text = "AKASHA TERMINAL"
        }

        val stepDetailText = TextView(this).apply {
            tag = "detail_step"
            textSize = 13f
            setTextColor(0xFFF8FAFC.toInt())
            text = "—"
            setPadding(0, 4, 0, 4)
        }

        val descText = TextView(this).apply {
            tag = "detail_desc"
            textSize = 11f
            setTextColor(0xFF94A3B8.toInt())
            text = ""
            maxWidth = 260.dpToPx()
        }

        val warningText = TextView(this).apply {
            tag = "detail_warning"
            textSize = 11f
            setTextColor(0xFFFBBF24.toInt()) // amber
            visibility = View.GONE
            setPadding(0, 6, 0, 0)
        }

        val stopBtn = TextView(this).apply {
            tag = "stop_btn"
            text = "■ Stop"
            textSize = 11f
            setTextColor(0xFFEF4444.toInt())
            setPadding(0, 8, 0, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val intent = Intent(this@OverlayService, AutomationExecutorService::class.java)
                intent.action = AutomationExecutorService.ACTION_STOP
                startService(intent)
                hideOverlay()
            }
        }

        detailPanel.addView(titleText)
        detailPanel.addView(stepDetailText)
        detailPanel.addView(descText)
        detailPanel.addView(warningText)
        detailPanel.addView(stopBtn)

        // Toggle expand/collapse
        infoBtn.setOnClickListener {
            isExpanded = !isExpanded
            detailPanel.visibility = if (isExpanded) View.VISIBLE else View.GONE
            infoBtn.setTextColor(
                if (isExpanded) 0xFF60A5FA.toInt() else 0xFF94A3B8.toInt()
            )
        }

        container.addView(miniBar)
        container.addView(detailPanel)

        return container
    }

    // ─── Update konten overlay ────────────────────────────────────────────────
    private fun updateOverlayContent() {
        val view = overlayView ?: return

        val riskColor = when (lastRisk) {
            "SAFE" -> 0xFF4ADE80.toInt()       // green
            "CAUTION" -> 0xFFFBBF24.toInt()    // amber
            "SENSITIVE" -> 0xFFFB923C.toInt()  // orange
            "DANGEROUS" -> 0xFFEF4444.toInt()  // red
            else -> 0xFF4ADE80.toInt()
        }

        val riskEmoji = when (lastRisk) {
            "SAFE" -> "✅"
            "CAUTION" -> "⚠️"
            "SENSITIVE" -> "🔐"
            "DANGEROUS" -> "🚨"
            else -> "●"
        }

        view.findViewWithTag<TextView>("risk_dot")?.setTextColor(riskColor)
        view.findViewWithTag<TextView>("step_text")?.text =
            "Step $lastStepNumber/$lastTotalSteps  $riskEmoji"

        view.findViewWithTag<TextView>("detail_title")?.text =
            lastTitle.uppercase().take(30)
        view.findViewWithTag<TextView>("detail_step")?.text =
            "$lastStepNumber. $lastStepTitle"
        view.findViewWithTag<TextView>("detail_desc")?.text = lastStepDesc

        val warningView = view.findViewWithTag<TextView>("detail_warning")
        if (lastWarning.isNotEmpty()) {
            warningView?.text = "⚠️ $lastWarning"
            warningView?.visibility = View.VISIBLE
        } else {
            warningView?.visibility = View.GONE
        }
    }

    // ─── Overlay input (OTP/password) ─────────────────────────────────────────
    private fun showInputOverlay(label: String, hint: String, isPassword: Boolean) {
        if (inputView != null) return

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 14, 16, 14)
            setBackgroundColor(0xF21E293B.toInt())
        }

        val labelText = TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(0xFFF8FAFC.toInt())
        }

        val editText = EditText(this).apply {
            if (hint.isNotEmpty()) this.hint = hint
            if (isPassword) {
                inputType = android.text.InputType.TYPE_CLASS_TEXT or
                        android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            setTextColor(0xFFF8FAFC.toInt())
            setHintTextColor(0xFF64748B.toInt())
            setPadding(8, 8, 8, 8)
            setBackgroundColor(0xFF0F172A.toInt())
        }

        val confirmBtn = TextView(this).apply {
            text = "Konfirmasi →"
            textSize = 13f
            setTextColor(0xFF60A5FA.toInt())
            setPadding(0, 12, 0, 0)
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val value = editText.text.toString()
                val intent = Intent(this@OverlayService, AutomationExecutorService::class.java).apply {
                    action = AutomationExecutorService.ACTION_PROVIDE_INPUT
                    putExtra(AutomationExecutorService.EXTRA_INPUT_VALUE, value)
                }
                startService(intent)
                hideInputOverlay()
            }
        }

        container.addView(labelText)
        container.addView(editText)
        container.addView(confirmBtn)

        val params = WindowManager.LayoutParams(
            300.dpToPx(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        inputView = container
        windowManager.addView(container, params)
    }

    private fun hideInputOverlay() {
        inputView?.let { windowManager.removeView(it) }
        inputView = null
    }

    private fun hideOverlay() {
        overlayView?.let { windowManager.removeView(it) }
        overlayView = null
        hideInputOverlay()
        stopSelf()
    }

    override fun onDestroy() {
        super.onDestroy()
        hideOverlay()
    }

    private fun Int.dpToPx(): Int = (this * resources.displayMetrics.density).toInt()
}
