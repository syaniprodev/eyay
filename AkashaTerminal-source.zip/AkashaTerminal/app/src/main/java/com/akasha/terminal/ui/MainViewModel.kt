package com.akasha.terminal.ui

import android.app.Application
import android.content.Intent
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.akasha.terminal.ai.*
import com.akasha.terminal.automation.AutomationExecutorService
import com.akasha.terminal.overlay.OverlayService
import com.akasha.terminal.utils.PreferencesManager
import com.akasha.terminal.utils.RootUtils
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val prefs = PreferencesManager(app)
    private val aiParser = AIParser(app)

    // ─── State utama ──────────────────────────────────────────────────────────
    private val _uiState = MutableStateFlow<UiState>(UiState.Idle)
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private val _commandText = MutableStateFlow("")
    val commandText: StateFlow<String> = _commandText.asStateFlow()

    private val _history = MutableStateFlow<List<HistoryItem>>(emptyList())
    val history: StateFlow<List<HistoryItem>> = _history.asStateFlow()

    // AI config dari DataStore
    val aiConfig = prefs.aiProviderConfig.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000),
        AIProviderConfig(AIProvider.GEMINI)
    )

    val isRootEnabled = prefs.isRootEnabled.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), false
    )

    val isFirstLaunch = prefs.isFirstLaunch.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), true
    )

    // Root availability (cek hardware)
    val isRootAvailable: Boolean by lazy {
        RootUtils.isRooted(getApplication())
    }

    fun updateCommandText(text: String) {
        _commandText.value = text
    }

    // ─── Parse perintah → pratinjau ───────────────────────────────────────────
    fun parseCommand() {
        val command = _commandText.value.trim()
        if (command.isEmpty()) return

        // Validasi API key kalau bukan local
        val config = aiConfig.value
        if (!config.isLocal && config.apiKey.isEmpty()) {
            _uiState.value = UiState.Error("API Key belum diatur. Buka Settings dulu.")
            return
        }

        _uiState.value = UiState.Parsing

        viewModelScope.launch {
            val useRoot = isRootEnabled.value && isRootAvailable

            val result = aiParser.parseCommand(command, config, useRoot)

            result.fold(
                onSuccess = { automation ->
                    _uiState.value = UiState.Preview(automation)
                },
                onFailure = { error ->
                    val errorMsg = when {
                        error.message?.contains("401") == true -> "API Key tidak valid"
                        error.message?.contains("429") == true -> "Quota API habis. Coba lagi nanti."
                        error.message?.contains("network") == true ||
                        error.message?.contains("connect") == true -> "Tidak ada koneksi internet"
                        else -> "Error: ${error.message}"
                    }
                    _uiState.value = UiState.Error(errorMsg)
                }
            )
        }
    }

    // ─── Jalankan automation setelah konfirmasi ───────────────────────────────
    fun executeAutomation(automation: ParsedAutomation) {
        val app = getApplication<Application>()

        // Start overlay service
        val overlayIntent = Intent(app, OverlayService::class.java).apply {
            action = OverlayService.ACTION_SHOW
        }
        app.startService(overlayIntent)

        // Start executor service
        val executorIntent = Intent(app, AutomationExecutorService::class.java).apply {
            action = AutomationExecutorService.ACTION_START
        }
        app.startService(executorIntent)

        _uiState.value = UiState.Executing(automation)

        // Tambah ke history
        addToHistory(HistoryItem(
            command = _commandText.value,
            title = automation.title,
            timestamp = System.currentTimeMillis()
        ))
        _commandText.value = ""
    }

    // ─── Batalkan / kembali ke idle ───────────────────────────────────────────
    fun cancel() {
        _uiState.value = UiState.Idle
    }

    fun reset() {
        _uiState.value = UiState.Idle
        _commandText.value = ""
    }

    // ─── History ──────────────────────────────────────────────────────────────
    private fun addToHistory(item: HistoryItem) {
        _history.update { current ->
            listOf(item) + current.take(49) // simpan max 50
        }
    }

    fun useHistoryCommand(command: String) {
        _commandText.value = command
        _uiState.value = UiState.Idle
    }

    // ─── Settings ─────────────────────────────────────────────────────────────
    fun saveAIConfig(config: AIProviderConfig) {
        viewModelScope.launch {
            prefs.saveAIConfig(config)
        }
    }

    fun setRootEnabled(enabled: Boolean) {
        viewModelScope.launch {
            prefs.setRootEnabled(enabled)
        }
    }

    fun completeFirstLaunch() {
        viewModelScope.launch {
            prefs.setFirstLaunchDone()
        }
    }
}

// ─── UI States ────────────────────────────────────────────────────────────────
sealed class UiState {
    object Idle : UiState()
    object Parsing : UiState()
    data class Preview(val automation: ParsedAutomation) : UiState()
    data class Executing(val automation: ParsedAutomation) : UiState()
    data class Error(val message: String) : UiState()
}

data class HistoryItem(
    val command: String,
    val title: String,
    val timestamp: Long
)
