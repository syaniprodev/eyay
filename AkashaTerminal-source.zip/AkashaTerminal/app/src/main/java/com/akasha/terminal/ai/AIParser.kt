package com.akasha.terminal.ai

import android.content.Context
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.JsonParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

class AIParser(private val context: Context) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    // ─── Prompt sistem yang dikirim ke AI ────────────────────────────────────
    private val SYSTEM_PROMPT = """
Kamu adalah Akasha Terminal, sebuah automation engine untuk Android.
Tugasmu: ubah perintah bahasa natural dari user menjadi daftar langkah otomatisasi yang terstruktur.

SELALU balas dalam format JSON berikut (tidak ada teks lain di luar JSON):
{
  "title": "Judul singkat task",
  "summary": "Ringkasan apa yang akan dilakukan",
  "estimatedDuration": "perkiraan waktu (e.g. '< 1 menit', '2-3 menit')",
  "requiresRoot": false,
  "overallRisk": "SAFE|CAUTION|SENSITIVE|DANGEROUS",
  "globalWarnings": ["peringatan umum jika ada"],
  "steps": [
    {
      "id": 1,
      "title": "Judul singkat langkah",
      "description": "Deskripsi detail apa yang dilakukan di langkah ini",
      "actionType": "OPEN_APP|CLICK|INPUT_TEXT|SCROLL|WAIT|PRESS_BACK|PRESS_HOME|OPEN_URL|REQUEST_INPUT|READ_CONTACTS|WRITE_CONTACTS|READ_FILE|WRITE_FILE|OPEN_SETTINGS|SHELL_COMMAND|TAKE_SCREENSHOT|COPY_TEXT|PASTE_TEXT|SWIPE|LONG_CLICK|CONDITIONAL",
      "params": { "key": "value" },
      "riskLevel": "SAFE|CAUTION|SENSITIVE|DANGEROUS",
      "warningMessage": "pesan peringatan spesifik jika ada, null jika tidak",
      "requiresRoot": false,
      "requiresUserInput": false,
      "userInputLabel": null,
      "userInputHint": null,
      "isPassword": false,
      "canSkip": false
    }
  ]
}

ATURAN RISK LEVEL:
- SAFE: membuka app, klik tombol biasa, scroll, navigasi
- CAUTION: mengakses file, mengubah pengaturan, otomatisasi login
- SENSITIVE: mengakses kontak/data pribadi, menginput password, akses akun
- DANGEROUS: menghapus data, perintah root, mengubah sistem, kirim data ke luar

ATURAN requiresUserInput:
- Set true jika step butuh OTP, password, PIN, kode verifikasi, atau data yang tidak bisa diisi otomatis
- Isi userInputLabel dengan label yang jelas (e.g. "Masukkan OTP WhatsApp")
- Set isPassword: true jika input adalah password/PIN

ATURAN params berdasarkan actionType:
- OPEN_APP: { "packageName": "com.xxx.xxx", "appName": "Nama App" }
- CLICK: { "targetText": "teks tombol/elemen", "resourceId": "id jika tau" }
- INPUT_TEXT: { "targetField": "nama field", "text": "teks yang diinput", "resourceId": "" }
- SCROLL: { "direction": "up|down|left|right", "amount": "small|medium|large" }
- WAIT: { "duration": "1000" } // dalam milliseconds
- OPEN_URL: { "url": "https://..." }
- REQUEST_INPUT: { "purpose": "untuk apa input ini" }
- SHELL_COMMAND: { "command": "perintah shell" }
- READ_CONTACTS / WRITE_CONTACTS: { "accountEmail": "email@gmail.com" }
""".trimIndent()

    // ─── Main parse function ──────────────────────────────────────────────────
    suspend fun parseCommand(
        userCommand: String,
        config: AIProviderConfig,
        isRootAvailable: Boolean
    ): Result<ParsedAutomation> = withContext(Dispatchers.IO) {
        try {
            val contextualCommand = buildString {
                append("Perintah user: $userCommand\n\n")
                append("Info device:\n")
                append("- Root tersedia: $isRootAvailable\n")
                append("- Android versi: ${android.os.Build.VERSION.RELEASE}\n")
                if (!isRootAvailable) {
                    append("\nCATATAN: Device tidak di-root. Jangan gunakan actionType SHELL_COMMAND.")
                }
            }

            val responseJson = when (config.provider) {
                AIProvider.GEMINI -> callGemini(contextualCommand, config)
                AIProvider.CLAUDE -> callClaude(contextualCommand, config)
                AIProvider.DEEPSEEK -> callDeepSeek(contextualCommand, config)
                AIProvider.OPENAI_COMPATIBLE -> callOpenAICompatible(contextualCommand, config)
                AIProvider.LOCAL_OLLAMA -> callOllama(contextualCommand, config)
            }

            val automation = parseJsonToAutomation(responseJson)
            Result.success(automation)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ─── Gemini API ───────────────────────────────────────────────────────────
    private fun callGemini(prompt: String, config: AIProviderConfig): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${config.apiKey}"
        val body = """
        {
          "system_instruction": {
            "parts": [{ "text": ${gson.toJson(SYSTEM_PROMPT)} }]
          },
          "contents": [{
            "parts": [{ "text": ${gson.toJson(prompt)} }]
          }],
          "generationConfig": {
            "temperature": 0.1,
            "responseMimeType": "application/json"
          }
        }
        """.trimIndent()

        val request = Request.Builder()
            .url(url)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Gemini: response kosong")
        
        if (!response.isSuccessful) {
            throw Exception("Gemini error ${response.code}: $responseBody")
        }

        val json = JsonParser.parseString(responseBody).asJsonObject
        return json
            .getAsJsonArray("candidates")
            .get(0).asJsonObject
            .getAsJsonObject("content")
            .getAsJsonArray("parts")
            .get(0).asJsonObject
            .get("text").asString
    }

    // ─── Claude (Anthropic) API ───────────────────────────────────────────────
    private fun callClaude(prompt: String, config: AIProviderConfig): String {
        val url = "https://api.anthropic.com/v1/messages"
        val body = gson.toJson(mapOf(
            "model" to (config.modelName.ifEmpty { "claude-haiku-3-5" }),
            "max_tokens" to 2048,
            "system" to SYSTEM_PROMPT,
            "messages" to listOf(mapOf("role" to "user", "content" to prompt))
        ))

        val request = Request.Builder()
            .url(url)
            .post(body.toRequestBody("application/json".toMediaType()))
            .addHeader("x-api-key", config.apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Claude: response kosong")

        if (!response.isSuccessful) {
            throw Exception("Claude error ${response.code}: $responseBody")
        }

        val json = JsonParser.parseString(responseBody).asJsonObject
        return json
            .getAsJsonArray("content")
            .get(0).asJsonObject
            .get("text").asString
    }

    // ─── DeepSeek API ─────────────────────────────────────────────────────────
    private fun callDeepSeek(prompt: String, config: AIProviderConfig): String {
        val url = "https://api.deepseek.com/v1/chat/completions"
        val body = gson.toJson(mapOf(
            "model" to (config.modelName.ifEmpty { "deepseek-chat" }),
            "messages" to listOf(
                mapOf("role" to "system", "content" to SYSTEM_PROMPT),
                mapOf("role" to "user", "content" to prompt)
            ),
            "temperature" to 0.1,
            "response_format" to mapOf("type" to "json_object")
        ))

        return callOpenAIFormat(url, config.apiKey, body)
    }

    // ─── OpenAI-compatible (custom endpoint) ─────────────────────────────────
    private fun callOpenAICompatible(prompt: String, config: AIProviderConfig): String {
        val url = "${config.baseUrl}/v1/chat/completions"
        val body = gson.toJson(mapOf(
            "model" to config.modelName,
            "messages" to listOf(
                mapOf("role" to "system", "content" to SYSTEM_PROMPT),
                mapOf("role" to "user", "content" to prompt)
            ),
            "temperature" to 0.1
        ))

        return callOpenAIFormat(url, config.apiKey, body)
    }

    // ─── Ollama (lokal) ───────────────────────────────────────────────────────
    private fun callOllama(prompt: String, config: AIProviderConfig): String {
        val baseUrl = config.baseUrl.ifEmpty { "http://localhost:11434" }
        val url = "$baseUrl/api/chat"
        val body = gson.toJson(mapOf(
            "model" to (config.modelName.ifEmpty { "llama3" }),
            "messages" to listOf(
                mapOf("role" to "system", "content" to SYSTEM_PROMPT),
                mapOf("role" to "user", "content" to prompt)
            ),
            "stream" to false,
            "format" to "json"
        ))

        val request = Request.Builder()
            .url(url)
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Ollama: response kosong")

        if (!response.isSuccessful) {
            throw Exception("Ollama error ${response.code}: $responseBody")
        }

        val json = JsonParser.parseString(responseBody).asJsonObject
        return json
            .getAsJsonObject("message")
            .get("content").asString
    }

    // ─── Helper: OpenAI format ────────────────────────────────────────────────
    private fun callOpenAIFormat(url: String, apiKey: String, body: String): String {
        val request = Request.Builder()
            .url(url)
            .post(body.toRequestBody("application/json".toMediaType()))
            .addHeader("Authorization", "Bearer $apiKey")
            .build()

        val response = client.newCall(request).execute()
        val responseBody = response.body?.string() ?: throw Exception("Response kosong")

        if (!response.isSuccessful) {
            throw Exception("API error ${response.code}: $responseBody")
        }

        val json = JsonParser.parseString(responseBody).asJsonObject
        return json
            .getAsJsonArray("choices")
            .get(0).asJsonObject
            .getAsJsonObject("message")
            .get("content").asString
    }

    // ─── Parse JSON → ParsedAutomation ───────────────────────────────────────
    private fun parseJsonToAutomation(jsonString: String): ParsedAutomation {
        // Bersihkan kalau ada markdown code block
        val cleanJson = jsonString
            .removePrefix("```json")
            .removePrefix("```")
            .removeSuffix("```")
            .trim()

        val json = JsonParser.parseString(cleanJson).asJsonObject

        val steps = json.getAsJsonArray("steps").map { stepEl ->
            val step = stepEl.asJsonObject
            AutomationStep(
                id = step.get("id").asInt,
                title = step.get("title").asString,
                description = step.get("description").asString,
                actionType = try {
                    ActionType.valueOf(step.get("actionType").asString)
                } catch (e: Exception) { ActionType.WAIT },
                params = try {
                    val paramsObj = step.getAsJsonObject("params")
                    paramsObj.entrySet().associate { it.key to it.value.asString }
                } catch (e: Exception) { emptyMap() },
                riskLevel = try {
                    RiskLevel.valueOf(step.get("riskLevel").asString)
                } catch (e: Exception) { RiskLevel.SAFE },
                warningMessage = step.get("warningMessage")?.let {
                    if (it.isJsonNull) null else it.asString
                },
                requiresRoot = step.get("requiresRoot")?.asBoolean ?: false,
                requiresUserInput = step.get("requiresUserInput")?.asBoolean ?: false,
                userInputLabel = step.get("userInputLabel")?.let {
                    if (it.isJsonNull) null else it.asString
                },
                userInputHint = step.get("userInputHint")?.let {
                    if (it.isJsonNull) null else it.asString
                },
                isPassword = step.get("isPassword")?.asBoolean ?: false,
                canSkip = step.get("canSkip")?.asBoolean ?: false
            )
        }

        val globalWarnings = try {
            json.getAsJsonArray("globalWarnings").map { it.asString }
        } catch (e: Exception) { emptyList() }

        return ParsedAutomation(
            title = json.get("title").asString,
            summary = json.get("summary").asString,
            steps = steps,
            overallRisk = try {
                RiskLevel.valueOf(json.get("overallRisk").asString)
            } catch (e: Exception) { RiskLevel.CAUTION },
            globalWarnings = globalWarnings,
            requiresRoot = json.get("requiresRoot")?.asBoolean ?: false,
            estimatedDuration = json.get("estimatedDuration")?.asString ?: "< 1 menit"
        )
    }
}
