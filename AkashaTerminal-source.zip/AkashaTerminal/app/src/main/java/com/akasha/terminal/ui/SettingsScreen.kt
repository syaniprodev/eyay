package com.akasha.terminal.ui

import android.provider.Settings
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.akasha.terminal.ai.AIProvider
import com.akasha.terminal.ai.AIProviderConfig

@Composable
fun SettingsScreen(
    config: AIProviderConfig,
    isRootAvailable: Boolean,
    isRootEnabled: Boolean,
    onRootToggle: (Boolean) -> Unit,
    onSaveConfig: (AIProviderConfig) -> Unit,
    onRequestOverlay: () -> Unit,
    onRequestAccessibility: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current

    var selectedProvider by remember { mutableStateOf(config.provider) }
    var apiKey by remember { mutableStateOf(config.apiKey) }
    var modelName by remember { mutableStateOf(config.modelName) }
    var baseUrl by remember { mutableStateOf(config.baseUrl) }
    var apiKeyVisible by remember { mutableStateOf(false) }

    val overlayGranted = Settings.canDrawOverlays(context)
    val accessibilityEnabled = remember { mutableStateOf(false) } // Will be checked

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Kembali", tint = AkashaTextSecondary)
            }
            Text("Pengaturan", color = AkashaText, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
        HorizontalDivider(color = AkashaSurfaceVariant)

        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // ── Izin yang dibutuhkan ────────────────────────────────────────
            SectionHeader("IZIN YANG DIBUTUHKAN")

            PermissionCard(
                title = "Overlay (Jendela Mengambang)",
                description = "Untuk menampilkan status step di atas app lain",
                isGranted = overlayGranted,
                onRequest = onRequestOverlay
            )

            PermissionCard(
                title = "Accessibility Service",
                description = "Engine utama untuk mengontrol dan mengotomatisasi app lain",
                isGranted = false, // Perlu cek dynamic
                onRequest = onRequestAccessibility,
                isImportant = true
            )

            // ── AI Engine ──────────────────────────────────────────────────
            SectionHeader("AI ENGINE")

            // Provider selector
            AIProviderSelector(
                selected = selectedProvider,
                onSelect = { selectedProvider = it }
            )

            // Input API key (kecuali local)
            if (selectedProvider != AIProvider.LOCAL_OLLAMA) {
                APIKeyInput(
                    value = apiKey,
                    onValueChange = { apiKey = it },
                    visible = apiKeyVisible,
                    onToggleVisible = { apiKeyVisible = !apiKeyVisible },
                    provider = selectedProvider
                )
            }

            // Model name (opsional untuk sebagian)
            if (selectedProvider in listOf(
                    AIProvider.CLAUDE, AIProvider.DEEPSEEK,
                    AIProvider.OPENAI_COMPATIBLE, AIProvider.LOCAL_OLLAMA
                )
            ) {
                SettingsTextField(
                    label = "Nama Model (opsional)",
                    value = modelName,
                    onValueChange = { modelName = it },
                    hint = when (selectedProvider) {
                        AIProvider.CLAUDE -> "claude-haiku-3-5 (default)"
                        AIProvider.DEEPSEEK -> "deepseek-chat (default)"
                        AIProvider.LOCAL_OLLAMA -> "llama3, mistral, dll"
                        else -> "nama model"
                    }
                )
            }

            // Base URL untuk custom/local
            if (selectedProvider in listOf(AIProvider.OPENAI_COMPATIBLE, AIProvider.LOCAL_OLLAMA)) {
                SettingsTextField(
                    label = "Base URL",
                    value = baseUrl,
                    onValueChange = { baseUrl = it },
                    hint = when (selectedProvider) {
                        AIProvider.LOCAL_OLLAMA -> "http://localhost:11434"
                        else -> "https://your-api-endpoint.com"
                    }
                )
            }

            // Info Gemini free tier
            if (selectedProvider == AIProvider.GEMINI) {
                InfoCard(
                    "💡 Gemini gratis 1500 request/hari. Daftar API key di:\naistudio.google.com"
                )
            }

            // Tombol simpan
            Button(
                onClick = {
                    onSaveConfig(AIProviderConfig(
                        provider = selectedProvider,
                        apiKey = apiKey,
                        modelName = modelName,
                        baseUrl = baseUrl,
                        isLocal = selectedProvider == AIProvider.LOCAL_OLLAMA
                    ))
                    onBack()
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AkashaAccent)
            ) {
                Text("Simpan Pengaturan AI", color = AkashaBackground, fontWeight = FontWeight.SemiBold)
            }

            // ── Root ───────────────────────────────────────────────────────
            SectionHeader("AKSES ROOT")

            RootSettingsCard(
                isRootAvailable = isRootAvailable,
                isRootEnabled = isRootEnabled,
                onToggle = onRootToggle
            )
        }
    }
}

@Composable
fun SectionHeader(title: String) {
    Text(
        title,
        color = AkashaTextMuted,
        fontSize = 11.sp,
        letterSpacing = 2.sp,
        modifier = Modifier.padding(top = 8.dp)
    )
}

@Composable
fun PermissionCard(
    title: String,
    description: String,
    isGranted: Boolean,
    onRequest: () -> Unit,
    isImportant: Boolean = false
) {
    Surface(
        color = AkashaSurface,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(
            1.dp,
            if (isGranted) ColorSafe.copy(alpha = 0.3f)
            else if (isImportant) ColorDangerous.copy(alpha = 0.3f)
            else AkashaSurfaceVariant
        )
    ) {
        Row(
            modifier = Modifier.padding(14.dp).fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(if (isGranted) "✅" else "⭕", fontSize = 20.sp)
            Column(modifier = Modifier.weight(1f)) {
                Text(title, color = AkashaText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(description, color = AkashaTextMuted, fontSize = 11.sp)
            }
            if (!isGranted) {
                TextButton(onClick = onRequest) {
                    Text("Izinkan", color = AkashaAccent, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun AIProviderSelector(selected: AIProvider, onSelect: (AIProvider) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Pilih AI Provider", color = AkashaTextSecondary, fontSize = 13.sp)

        val providers = listOf(
            Triple(AIProvider.GEMINI, "Gemini", "Google • Free 1500/hari"),
            Triple(AIProvider.CLAUDE, "Claude", "Anthropic • Bayar"),
            Triple(AIProvider.DEEPSEEK, "DeepSeek", "DeepSeek • Murah"),
            Triple(AIProvider.OPENAI_COMPATIBLE, "Custom OpenAI", "API compatible lainnya"),
            Triple(AIProvider.LOCAL_OLLAMA, "Lokal (Ollama)", "Offline • HP harus kuat")
        )

        providers.forEach { (provider, name, desc) ->
            ProviderOption(
                name = name,
                description = desc,
                isSelected = selected == provider,
                onClick = { onSelect(provider) }
            )
        }
    }
}

@Composable
fun ProviderOption(name: String, description: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (isSelected) AkashaAccent.copy(alpha = 0.1f) else AkashaSurface,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(
            1.dp,
            if (isSelected) AkashaAccent.copy(alpha = 0.5f) else AkashaSurfaceVariant
        ),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = AkashaAccent)
            )
            Column {
                Text(name, color = AkashaText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text(description, color = AkashaTextMuted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun APIKeyInput(
    value: String,
    onValueChange: (String) -> Unit,
    visible: Boolean,
    onToggleVisible: () -> Unit,
    provider: AIProvider
) {
    val hint = when (provider) {
        AIProvider.GEMINI -> "AIza..."
        AIProvider.CLAUDE -> "sk-ant-..."
        AIProvider.DEEPSEEK -> "sk-..."
        else -> "API Key"
    }

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text("API Key") },
        placeholder = { Text(hint, color = AkashaTextMuted) },
        visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
        trailingIcon = {
            IconButton(onClick = onToggleVisible) {
                Icon(
                    if (visible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    "Toggle visibility",
                    tint = AkashaTextMuted
                )
            }
        },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = AkashaText,
            unfocusedTextColor = AkashaText,
            focusedBorderColor = AkashaAccent,
            unfocusedBorderColor = AkashaSurfaceVariant,
            focusedLabelColor = AkashaAccent,
            unfocusedLabelColor = AkashaTextMuted,
            focusedContainerColor = AkashaSurfaceVariant,
            unfocusedContainerColor = AkashaSurfaceVariant,
            cursorColor = AkashaAccent
        ),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        singleLine = true
    )
}

@Composable
fun SettingsTextField(label: String, value: String, onValueChange: (String) -> Unit, hint: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        placeholder = { Text(hint, color = AkashaTextMuted) },
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = AkashaText,
            unfocusedTextColor = AkashaText,
            focusedBorderColor = AkashaAccent,
            unfocusedBorderColor = AkashaSurfaceVariant,
            focusedLabelColor = AkashaAccent,
            unfocusedLabelColor = AkashaTextMuted,
            focusedContainerColor = AkashaSurfaceVariant,
            unfocusedContainerColor = AkashaSurfaceVariant,
            cursorColor = AkashaAccent
        ),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        singleLine = true
    )
}

@Composable
fun InfoCard(text: String) {
    Surface(
        color = AkashaAccent.copy(alpha = 0.08f),
        shape = RoundedCornerShape(8.dp)
    ) {
        Text(text, color = AkashaAccent.copy(alpha = 0.8f), fontSize = 12.sp,
            modifier = Modifier.padding(12.dp))
    }
}

@Composable
fun RootSettingsCard(
    isRootAvailable: Boolean,
    isRootEnabled: Boolean,
    onToggle: (Boolean) -> Unit
) {
    Surface(
        color = AkashaSurface,
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Aktifkan Akses Root", color = AkashaText, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                    Text(
                        if (isRootAvailable) "HP terdeteksi ter-root" else "HP tidak terdeteksi ter-root",
                        color = if (isRootAvailable) ColorSafe else AkashaTextMuted,
                        fontSize = 11.sp
                    )
                }
                Switch(
                    checked = isRootEnabled && isRootAvailable,
                    onCheckedChange = { if (isRootAvailable) onToggle(it) },
                    enabled = isRootAvailable,
                    colors = SwitchDefaults.colors(checkedThumbColor = AkashaBackground, checkedTrackColor = AkashaAccent)
                )
            }

            if (!isRootAvailable) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "HP kamu tidak di-root atau Magisk/KSU belum terinstal. Root memberikan akses lebih banyak tapi tidak wajib.",
                    color = AkashaTextMuted,
                    fontSize = 11.sp
                )
            }

            if (isRootEnabled && isRootAvailable) {
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = ColorDangerous.copy(alpha = 0.08f),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        "⚠️ Root aktif. Perintah berbahaya seperti hapus file sistem bisa dijalankan. Gunakan dengan bijak.",
                        color = ColorDangerous.copy(alpha = 0.8f),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(10.dp)
                    )
                }
            }
        }
    }
}
