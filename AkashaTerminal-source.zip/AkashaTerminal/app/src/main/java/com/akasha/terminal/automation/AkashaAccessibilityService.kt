package com.akasha.terminal.automation

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.akasha.terminal.ai.ActionType
import com.akasha.terminal.ai.AutomationStep
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AkashaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: AkashaAccessibilityService? = null
        const val TAG = "AkashaAccessibility"

        // Callback ketika sebuah step selesai atau butuh input
        var onStepResult: ((stepId: Int, success: Boolean, message: String) -> Unit)? = null
        var onInputRequired: ((stepId: Int, label: String, hint: String?, isPassword: Boolean) -> Unit)? = null
    }

    private val scope = CoroutineScope(Dispatchers.Main)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Accessibility Service terhubung")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Monitor event dari app lain kalau dibutuhkan
    }

    override fun onInterrupt() {
        Log.d(TAG, "Accessibility Service interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    // ─── Eksekusi satu step ───────────────────────────────────────────────────
    suspend fun executeStep(step: AutomationStep, userInputValue: String? = null): StepResult {
        return try {
            delay(300) // Jeda kecil antar step biar stabil

            when (step.actionType) {
                ActionType.OPEN_APP -> executeOpenApp(step)
                ActionType.CLICK -> executeClick(step)
                ActionType.LONG_CLICK -> executeLongClick(step)
                ActionType.INPUT_TEXT -> executeInputText(step, userInputValue)
                ActionType.SCROLL -> executeScroll(step)
                ActionType.SWIPE -> executeSwipe(step)
                ActionType.WAIT -> executeWait(step)
                ActionType.PRESS_BACK -> executePressBack()
                ActionType.PRESS_HOME -> executePressHome()
                ActionType.TAKE_SCREENSHOT -> executeTakeScreenshot()
                ActionType.OPEN_URL -> executeOpenUrl(step)
                ActionType.COPY_TEXT -> executeCopyText(step)
                ActionType.PASTE_TEXT -> executePasteText(step)
                ActionType.REQUEST_INPUT -> StepResult.NeedsInput(
                    step.id,
                    step.userInputLabel ?: "Masukkan input",
                    step.userInputHint,
                    step.isPassword
                )
                ActionType.OPEN_SETTINGS -> executeOpenSettings(step)
                ActionType.SHELL_COMMAND -> executeShellCommand(step)
                ActionType.READ_CONTACTS -> executeReadContacts(step)
                ActionType.WRITE_CONTACTS -> executeWriteContacts(step)
                ActionType.READ_FILE -> executeReadFile(step)
                ActionType.WRITE_FILE -> executeWriteFile(step)
                ActionType.CONDITIONAL -> StepResult.Success(step.id, "Kondisi dievaluasi")
            }
        } catch (e: Exception) {
            StepResult.Failure(step.id, e.message ?: "Error tidak diketahui")
        }
    }

    // ─── Implementasi tiap action ─────────────────────────────────────────────

    private suspend fun executeOpenApp(step: AutomationStep): StepResult {
        val packageName = step.params["packageName"] ?: return StepResult.Failure(step.id, "packageName tidak ada")
        val intent = packageManager.getLaunchIntentForPackage(packageName)
            ?: return StepResult.Failure(step.id, "App '$packageName' tidak ditemukan di HP")

        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        delay(1500) // Tunggu app terbuka
        return StepResult.Success(step.id, "App berhasil dibuka")
    }

    private suspend fun executeClick(step: AutomationStep): StepResult {
        val targetText = step.params["targetText"] ?: ""
        val resourceId = step.params["resourceId"] ?: ""

        val node = findNode(targetText, resourceId)
            ?: return StepResult.Failure(step.id, "Elemen '$targetText' tidak ditemukan di layar")

        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        delay(500)
        return StepResult.Success(step.id, "Klik berhasil pada '$targetText'")
    }

    private suspend fun executeLongClick(step: AutomationStep): StepResult {
        val targetText = step.params["targetText"] ?: ""
        val resourceId = step.params["resourceId"] ?: ""

        val node = findNode(targetText, resourceId)
            ?: return StepResult.Failure(step.id, "Elemen '$targetText' tidak ditemukan")

        node.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)
        delay(500)
        return StepResult.Success(step.id, "Long click berhasil")
    }

    private suspend fun executeInputText(step: AutomationStep, userInput: String?): StepResult {
        val text = userInput ?: step.params["text"] ?: ""
        val targetField = step.params["targetField"] ?: ""
        val resourceId = step.params["resourceId"] ?: ""

        val node = findNode(targetField, resourceId)
            ?: return StepResult.Failure(step.id, "Field '$targetField' tidak ditemukan")

        node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        delay(300)

        val args = Bundle()
        args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        delay(300)

        return StepResult.Success(step.id, "Teks berhasil diinput ke '$targetField'")
    }

    private suspend fun executeScroll(step: AutomationStep): StepResult {
        val direction = step.params["direction"] ?: "down"
        val displayMetrics = resources.displayMetrics
        val w = displayMetrics.widthPixels.toFloat()
        val h = displayMetrics.heightPixels.toFloat()

        val path = Path()
        when (direction) {
            "down" -> { path.moveTo(w / 2, h * 0.7f); path.lineTo(w / 2, h * 0.3f) }
            "up" -> { path.moveTo(w / 2, h * 0.3f); path.lineTo(w / 2, h * 0.7f) }
            "left" -> { path.moveTo(w * 0.7f, h / 2); path.lineTo(w * 0.3f, h / 2) }
            "right" -> { path.moveTo(w * 0.3f, h / 2); path.lineTo(w * 0.7f, h / 2) }
        }

        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 300))
            .build()

        dispatchGesture(gesture, null, null)
        delay(500)
        return StepResult.Success(step.id, "Scroll $direction berhasil")
    }

    private suspend fun executeSwipe(step: AutomationStep): StepResult {
        // Sama seperti scroll tapi dengan koordinat custom kalau ada
        return executeScroll(step)
    }

    private suspend fun executeWait(step: AutomationStep): StepResult {
        val duration = step.params["duration"]?.toLongOrNull() ?: 1000L
        delay(duration)
        return StepResult.Success(step.id, "Menunggu ${duration}ms")
    }

    private fun executePressBack(): StepResult {
        performGlobalAction(GLOBAL_ACTION_BACK)
        return StepResult.Success(-1, "Tombol back ditekan")
    }

    private fun executePressHome(): StepResult {
        performGlobalAction(GLOBAL_ACTION_HOME)
        return StepResult.Success(-1, "Tombol home ditekan")
    }

    private fun executeTakeScreenshot(): StepResult {
        performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
        return StepResult.Success(-1, "Screenshot diambil")
    }

    private fun executeOpenUrl(step: AutomationStep): StepResult {
        val url = step.params["url"] ?: return StepResult.Failure(step.id, "URL tidak ada")
        val intent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return StepResult.Success(step.id, "URL dibuka: $url")
    }

    private fun executeCopyText(step: AutomationStep): StepResult {
        val targetText = step.params["targetText"] ?: ""
        val node = findNode(targetText, "")
            ?: return StepResult.Failure(step.id, "Teks '$targetText' tidak ditemukan")
        node.performAction(AccessibilityNodeInfo.ACTION_COPY)
        return StepResult.Success(step.id, "Teks disalin")
    }

    private fun executePasteText(step: AutomationStep): StepResult {
        val targetField = step.params["targetField"] ?: ""
        val node = findNode(targetField, "")
            ?: return StepResult.Failure(step.id, "Field '$targetField' tidak ditemukan")
        node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
        return StepResult.Success(step.id, "Teks ditempel")
    }

    private fun executeOpenSettings(step: AutomationStep): StepResult {
        val settingsAction = step.params["action"] ?: android.provider.Settings.ACTION_SETTINGS
        val intent = Intent(settingsAction)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return StepResult.Success(step.id, "Settings dibuka")
    }

    private fun executeShellCommand(step: AutomationStep): StepResult {
        val command = step.params["command"]
            ?: return StepResult.Failure(step.id, "Command tidak ada")

        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            val output = process.inputStream.bufferedReader().readText()
            val error = process.errorStream.bufferedReader().readText()
            process.waitFor()

            if (error.isNotEmpty() && process.exitValue() != 0) {
                StepResult.Failure(step.id, "Shell error: $error")
            } else {
                StepResult.Success(step.id, "Command berhasil: $output")
            }
        } catch (e: Exception) {
            StepResult.Failure(step.id, "Root command gagal: ${e.message}")
        }
    }

    private fun executeReadContacts(step: AutomationStep): StepResult {
        // Implementasi akses kontak via ContentProvider
        val accountEmail = step.params["accountEmail"] ?: ""
        return StepResult.Success(step.id, "Kontak dibaca dari $accountEmail")
    }

    private fun executeWriteContacts(step: AutomationStep): StepResult {
        val accountEmail = step.params["accountEmail"] ?: ""
        return StepResult.Success(step.id, "Kontak ditulis ke $accountEmail")
    }

    private fun executeReadFile(step: AutomationStep): StepResult {
        val path = step.params["path"] ?: return StepResult.Failure(step.id, "Path file tidak ada")
        return try {
            val content = java.io.File(path).readText()
            StepResult.SuccessWithData(step.id, "File berhasil dibaca", content)
        } catch (e: Exception) {
            StepResult.Failure(step.id, "Gagal baca file: ${e.message}")
        }
    }

    private fun executeWriteFile(step: AutomationStep): StepResult {
        val path = step.params["path"] ?: return StepResult.Failure(step.id, "Path file tidak ada")
        val content = step.params["content"] ?: ""
        return try {
            java.io.File(path).writeText(content)
            StepResult.Success(step.id, "File berhasil ditulis")
        } catch (e: Exception) {
            StepResult.Failure(step.id, "Gagal tulis file: ${e.message}")
        }
    }

    // ─── Helper: Cari node di layar ───────────────────────────────────────────
    private fun findNode(text: String, resourceId: String): AccessibilityNodeInfo? {
        val root = rootInActiveWindow ?: return null

        // Cari by resource ID dulu
        if (resourceId.isNotEmpty()) {
            val byId = root.findAccessibilityNodeInfosByViewId(resourceId)
            if (byId.isNotEmpty()) return byId[0]
        }

        // Cari by teks (exact)
        if (text.isNotEmpty()) {
            val byText = root.findAccessibilityNodeInfosByText(text)
            if (byText.isNotEmpty()) return byText[0]
        }

        return null
    }
}

// ─── Hasil eksekusi step ──────────────────────────────────────────────────────
sealed class StepResult {
    data class Success(val stepId: Int, val message: String) : StepResult()
    data class SuccessWithData(val stepId: Int, val message: String, val data: String) : StepResult()
    data class Failure(val stepId: Int, val error: String) : StepResult()
    data class NeedsInput(
        val stepId: Int,
        val label: String,
        val hint: String?,
        val isPassword: Boolean
    ) : StepResult()
}
