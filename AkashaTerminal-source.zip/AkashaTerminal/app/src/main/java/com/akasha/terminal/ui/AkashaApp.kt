package com.akasha.terminal.ui

import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.akasha.terminal.ai.*

@Composable
fun AkashaApp(
    viewModel: MainViewModel,
    onRequestOverlayPermission: () -> Unit,
    onRequestAccessibilityPermission: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val commandText by viewModel.commandText.collectAsStateWithLifecycle()
    val history by viewModel.history.collectAsStateWithLifecycle()
    val aiConfig by viewModel.aiConfig.collectAsStateWithLifecycle()
    val isRootEnabled by viewModel.isRootEnabled.collectAsStateWithLifecycle()
    val isFirstLaunch by viewModel.isFirstLaunch.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var showSettings by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }

    // First launch: langsung buka settings
    LaunchedEffect(isFirstLaunch) {
        if (isFirstLaunch) {
            showSettings = true
            viewModel.completeFirstLaunch()
        }
    }

    Box(modifier = Modifier.fillMaxSize().background(AkashaBackground)) {
        when {
            showSettings -> SettingsScreen(
                config = aiConfig,
                isRootAvailable = viewModel.isRootAvailable,
                isRootEnabled = isRootEnabled,
                onRootToggle = { viewModel.setRootEnabled(it) },
                onSaveConfig = { viewModel.saveAIConfig(it) },
                onRequestOverlay = onRequestOverlayPermission,
                onRequestAccessibility = onRequestAccessibilityPermission,
                onBack = { showSettings = false }
            )
            showHistory -> HistoryScreen(
                history = history,
                onUseCommand = {
                    viewModel.useHistoryCommand(it)
                    showHistory = false
                },
                onBack = { showHistory = false }
            )
            else -> MainScreen(
                commandText = commandText,
                uiState = uiState,
                onCommandChange = viewModel::updateCommandText,
                onParse = viewModel::parseCommand,
                onExecute = viewModel::executeAutomation,
                onCancel = viewModel::cancel,
                onReset = viewModel::reset,
                onOpenSettings = { showSettings = true },
                onOpenHistory = { showHistory = true }
            )
        }
    }
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
@Composable
fun MainScreen(
    commandText: String,
    uiState: UiState,
    onCommandChange: (String) -> Unit,
    onParse: () -> Unit,
    onExecute: (ParsedAutomation) -> Unit,
    onCancel: () -> Unit,
    onReset: () -> Unit,
    onOpenSettings: () -> Unit,
    onOpenHistory: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // ── Header ───────────────────────────────────────────────────────────
        TopBar(onOpenSettings = onOpenSettings, onOpenHistory = onOpenHistory)

        // ── Content ──────────────────────────────────────────────────────────
        Box(modifier = Modifier.weight(1f).padding(horizontal = 16.dp)) {
            when (val state = uiState) {
                is UiState.Idle -> IdleContent()
                is UiState.Parsing -> ParsingContent()
                is UiState.Preview -> PreviewContent(
                    automation = state.automation,
                    onExecute = { onExecute(state.automation) },
                    onCancel = onCancel
                )
                is UiState.Executing -> ExecutingContent(
                    automation = state.automation,
                    onDone = onReset
                )
                is UiState.Error -> ErrorContent(
                    message = state.message,
                    onRetry = onParse,
                    onCancel = onReset
                )
            }
        }

        // ── Command Input (selalu di bawah) ───────────────────────────────
        if (uiState is UiState.Idle || uiState is UiState.Error) {
            CommandInput(
                text = commandText,
                onTextChange = onCommandChange,
                onSubmit = onParse,
                isEnabled = uiState !is UiState.Parsing
            )
        }
    }
}

@Composable
fun TopBar(onOpenSettings: () -> Unit, onOpenHistory: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "AKASHA",
                color = AkashaAccent,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 4.sp
            )
            Text(
                text = "TERMINAL",
                color = AkashaTextSecondary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 6.sp
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconButton(onClick = onOpenHistory) {
                Icon(Icons.Default.History, "Riwayat", tint = AkashaTextSecondary)
            }
            IconButton(onClick = onOpenSettings) {
                Icon(Icons.Default.Settings, "Pengaturan", tint = AkashaTextSecondary)
            }
        }
    }
    HorizontalDivider(color = AkashaSurfaceVariant, thickness = 1.dp)
}

@Composable
fun CommandInput(
    text: String,
    onTextChange: (String) -> Unit,
    onSubmit: () -> Unit,
    isEnabled: Boolean
) {
    Surface(color = AkashaSurface) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.Bottom,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = onTextChange,
                modifier = Modifier.weight(1f),
                placeholder = {
                    Text(
                        "Ketik perintah... (e.g. 'pindahkan kontak dari akun A ke B')",
                        color = AkashaTextMuted,
                        fontSize = 13.sp
                    )
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = AkashaText,
                    unfocusedTextColor = AkashaText,
                    focusedBorderColor = AkashaAccent,
                    unfocusedBorderColor = AkashaSurfaceVariant,
                    cursorColor = AkashaAccent,
                    focusedContainerColor = AkashaSurfaceVariant,
                    unfocusedContainerColor = AkashaSurfaceVariant
                ),
                shape = RoundedCornerShape(12.dp),
                enabled = isEnabled,
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSubmit() }),
                textStyle = androidx.compose.ui.text.TextStyle(
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 14.sp
                )
            )
            FilledIconButton(
                onClick = onSubmit,
                enabled = isEnabled && text.isNotBlank(),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = AkashaAccent,
                    disabledContainerColor = AkashaSurfaceVariant
                ),
                modifier = Modifier.size(48.dp)
            ) {
                Icon(
                    Icons.Default.Send,
                    "Kirim",
                    tint = if (isEnabled && text.isNotBlank()) AkashaBackground else AkashaTextMuted
                )
            }
        }
    }
}

@Composable
fun IdleContent() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("⚡", fontSize = 48.sp)
            Text(
                "Ketik perintah untuk memulai",
                color = AkashaTextSecondary,
                fontSize = 15.sp
            )
            Text(
                "AI akan menganalisis dan membuat alur otomatisasi\nuntuk kamu konfirmasi sebelum dijalankan",
                color = AkashaTextMuted,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )

            Spacer(Modifier.height(16.dp))

            // Contoh perintah
            Text("Contoh:", color = AkashaTextMuted, fontSize = 11.sp)
            listOf(
                "Pindahkan semua kontak dari Gmail lama ke Gmail baru",
                "Aktifkan mode hemat baterai dan matikan WiFi",
                "Buka Shopee dan cari 'baju hitam' urutkan harga termurah"
            ).forEach { example ->
                ExampleChip(text = example)
            }
        }
    }
}

@Composable
fun ExampleChip(text: String) {
    Surface(
        color = AkashaSurfaceVariant,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth(0.85f)
    ) {
        Text(
            text = text,
            color = AkashaTextSecondary,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            maxLines = 2
        )
    }
}

@Composable
fun ParsingContent() {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(color = AkashaAccent, strokeWidth = 2.dp)
            Text("Menganalisis perintah...", color = AkashaTextSecondary)
            Text("AI sedang membuat alur otomatisasi", color = AkashaTextMuted, fontSize = 12.sp)
        }
    }
}

// ─── Preview Screen (pratinjau alur) ─────────────────────────────────────────
@Composable
fun PreviewContent(
    automation: ParsedAutomation,
    onExecute: () -> Unit,
    onCancel: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(8.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Header automation
        item {
            AutomationHeader(automation)
        }

        // Global warnings
        if (automation.globalWarnings.isNotEmpty()) {
            item {
                GlobalWarningsCard(automation.globalWarnings)
            }
        }

        // Steps
        item {
            Text(
                "ALUR EKSEKUSI",
                color = AkashaTextMuted,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp,
                modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
            )
        }

        items(automation.steps) { step ->
            StepCard(step = step)
        }

        // Action buttons
        item {
            Spacer(Modifier.height(8.dp))
            ActionButtons(
                onExecute = onExecute,
                onCancel = onCancel,
                risk = automation.overallRisk
            )
        }
    }
}

@Composable
fun AutomationHeader(automation: ParsedAutomation) {
    Surface(
        color = AkashaSurfaceVariant,
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    automation.title,
                    color = AkashaText,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                    modifier = Modifier.weight(1f)
                )
                RiskBadge(automation.overallRisk)
            }
            Spacer(Modifier.height(6.dp))
            Text(automation.summary, color = AkashaTextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                InfoChip("${automation.steps.size} langkah")
                InfoChip("⏱ ${automation.estimatedDuration}")
                if (automation.requiresRoot) InfoChip("🔑 Root")
            }
        }
    }
}

@Composable
fun RiskBadge(risk: RiskLevel) {
    val (color, label) = when (risk) {
        RiskLevel.SAFE -> Pair(ColorSafe, "AMAN")
        RiskLevel.CAUTION -> Pair(ColorCaution, "HATI-HATI")
        RiskLevel.SENSITIVE -> Pair(ColorSensitive, "SENSITIF")
        RiskLevel.DANGEROUS -> Pair(ColorDangerous, "BAHAYA")
    }
    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f))
    ) {
        Text(
            label,
            color = color,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

@Composable
fun InfoChip(text: String) {
    Text(text, color = AkashaTextMuted, fontSize = 11.sp)
}

@Composable
fun GlobalWarningsCard(warnings: List<String>) {
    Surface(
        color = ColorCaution.copy(alpha = 0.08f),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, ColorCaution.copy(alpha = 0.3f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text("⚠️ Peringatan", color = ColorCaution, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            warnings.forEach { warning ->
                Text("• $warning", color = ColorCaution.copy(alpha = 0.8f), fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun StepCard(step: AutomationStep) {
    var expanded by remember { mutableStateOf(false) }

    val riskColor = when (step.riskLevel) {
        RiskLevel.SAFE -> ColorSafe
        RiskLevel.CAUTION -> ColorCaution
        RiskLevel.SENSITIVE -> ColorSensitive
        RiskLevel.DANGEROUS -> ColorDangerous
    }

    Surface(
        color = AkashaSurface,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, riskColor.copy(alpha = 0.2f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column {
            // Row utama
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded }
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Nomor step
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(riskColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        "${step.id}",
                        color = riskColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Judul & action type
                Column(modifier = Modifier.weight(1f)) {
                    Text(step.title, color = AkashaText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                    Text(
                        step.actionType.name.replace("_", " "),
                        color = AkashaTextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Ikon warning kalau ada
                if (step.warningMessage != null) {
                    Text("⚠️", fontSize = 14.sp)
                }
                if (step.requiresUserInput) {
                    Text("⌨️", fontSize = 14.sp)
                }

                // Arrow expand
                Icon(
                    if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    "Detail",
                    tint = AkashaTextMuted,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Detail expanded
            AnimatedVisibility(visible = expanded) {
                Column(
                    modifier = Modifier
                        .background(AkashaSurfaceVariant)
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(step.description, color = AkashaTextSecondary, fontSize = 12.sp)

                    if (step.requiresUserInput) {
                        Surface(
                            color = AkashaAccent.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                "⌨️ Butuh input: ${step.userInputLabel ?: "Data dari kamu"}",
                                color = AkashaAccent,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    if (step.warningMessage != null) {
                        Surface(
                            color = ColorCaution.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                "⚠️ ${step.warningMessage}",
                                color = ColorCaution,
                                fontSize = 11.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }

                    if (step.requiresRoot) {
                        Text(
                            "🔑 Membutuhkan akses root",
                            color = ColorSensitive,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ActionButtons(onExecute: () -> Unit, onCancel: () -> Unit, risk: RiskLevel) {
    val executeColor = when (risk) {
        RiskLevel.DANGEROUS -> ColorDangerous
        RiskLevel.SENSITIVE -> ColorSensitive
        else -> AkashaAccent
    }

    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (risk == RiskLevel.DANGEROUS) {
            Surface(
                color = ColorDangerous.copy(alpha = 0.1f),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, ColorDangerous.copy(alpha = 0.4f))
            ) {
                Text(
                    "🚨 Task ini mengandung aksi berbahaya. Pastikan kamu memahami risikonya sebelum melanjutkan.",
                    color = ColorDangerous,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = onCancel,
                modifier = Modifier.weight(1f),
                border = BorderStroke(1.dp, AkashaSurfaceVariant)
            ) {
                Text("Batal", color = AkashaTextSecondary)
            }

            Button(
                onClick = onExecute,
                modifier = Modifier.weight(2f),
                colors = ButtonDefaults.buttonColors(containerColor = executeColor)
            ) {
                Text(
                    if (risk == RiskLevel.DANGEROUS) "⚡ Jalankan (Saya Mengerti Risikonya)"
                    else "⚡ Jalankan Sekarang",
                    color = AkashaBackground,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun ExecutingContent(automation: ParsedAutomation, onDone: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            CircularProgressIndicator(color = AkashaAccent)
            Text(
                "Menjalankan: ${automation.title}",
                color = AkashaText,
                fontWeight = FontWeight.Medium
            )
            Text(
                "Lihat overlay di pojok layar untuk status step",
                color = AkashaTextSecondary,
                fontSize = 13.sp
            )
            Text(
                "Kamu bisa menggunakan HP seperti biasa.\nAkasha bekerja di background.",
                color = AkashaTextMuted,
                fontSize = 12.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = onDone,
                border = BorderStroke(1.dp, AkashaSurfaceVariant)
            ) {
                Text("Kembali ke Home", color = AkashaTextSecondary)
            }
        }
    }
}

@Composable
fun ErrorContent(message: String, onRetry: () -> Unit, onCancel: () -> Unit) {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.padding(horizontal = 24.dp)
        ) {
            Text("⚠️", fontSize = 40.sp)
            Text(message, color = ColorDangerous, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = onCancel,
                    border = BorderStroke(1.dp, AkashaSurfaceVariant)
                ) {
                    Text("Batal", color = AkashaTextSecondary)
                }
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = AkashaAccent)
                ) {
                    Text("Coba Lagi", color = AkashaBackground)
                }
            }
        }
    }
}

// ─── History Screen ───────────────────────────────────────────────────────────
@Composable
fun HistoryScreen(
    history: List<HistoryItem>,
    onUseCommand: (String) -> Unit,
    onBack: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, "Kembali", tint = AkashaTextSecondary)
            }
            Text("Riwayat Perintah", color = AkashaText, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
        }
        HorizontalDivider(color = AkashaSurfaceVariant)

        if (history.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Belum ada riwayat", color = AkashaTextMuted)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(history) { item ->
                    HistoryItemCard(item = item, onUse = { onUseCommand(item.command) })
                }
            }
        }
    }
}

@Composable
fun HistoryItemCard(item: HistoryItem, onUse: () -> Unit) {
    Surface(
        color = AkashaSurface,
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onUse)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(item.title, color = AkashaText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            Text(
                item.command,
                color = AkashaTextSecondary,
                fontSize = 12.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                formatTime(item.timestamp),
                color = AkashaTextMuted,
                fontSize = 10.sp,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}

private fun formatTime(timestamp: Long): String {
    val sdf = java.text.SimpleDateFormat("dd MMM yyyy, HH:mm", java.util.Locale("id", "ID"))
    return sdf.format(java.util.Date(timestamp))
}
