# Akasha Terminal

Automation engine untuk Android dengan AI-powered natural language processing.

## Cara Build

### Requirement
- Android Studio Hedgehog (2023.1.1) atau lebih baru
- JDK 17
- Android SDK 34

### Langkah Build
1. Buka Android Studio
2. File → Open → pilih folder `AkashaTerminal`
3. Tunggu Gradle sync selesai
4. Build → Build Bundle(s)/APK(s) → Build APK(s)
5. APK ada di `app/build/outputs/apk/debug/app-debug.apk`

## Cara Pakai Pertama Kali

1. Install APK
2. Buka Akasha Terminal
3. Settings otomatis terbuka → pilih AI Provider
4. Masukkan API Key (Gemini gratis di aistudio.google.com)
5. Izinkan:
   - **Overlay** (jendela mengambang) → wajib
   - **Accessibility Service** → wajib (cari "Akasha Terminal" di list)
6. Ketik perintah → AI generate alur → konfirmasi → jalan!

## Struktur Project

```
com.akasha.terminal/
├── ai/
│   ├── Models.kt          - Data models (Step, ParsedAutomation, dll)
│   └── AIParser.kt        - Koneksi ke AI API (Gemini, Claude, DeepSeek, dll)
├── automation/
│   ├── AkashaAccessibilityService.kt  - Core executor (klik, input, scroll, dll)
│   └── AutomationExecutorService.kt   - Orchestrator alur eksekusi
├── overlay/
│   └── OverlayService.kt  - Jendela mengambang status step
├── ui/
│   ├── MainActivity.kt    - Entry point
│   ├── MainViewModel.kt   - State management
│   ├── AkashaApp.kt       - UI utama (Compose)
│   ├── SettingsScreen.kt  - Halaman pengaturan
│   └── Theme.kt           - Warna & tema
└── utils/
    ├── PreferencesManager.kt  - Simpan settings (DataStore)
    └── RootUtils.kt           - Deteksi root
```

## AI Providers yang Didukung

| Provider | Gratis? | Offline? | Link |
|---|---|---|---|
| Gemini | ✅ 1500/hari | ❌ | aistudio.google.com |
| Claude | ❌ Bayar | ❌ | console.anthropic.com |
| DeepSeek | ✅ Limited | ❌ | platform.deepseek.com |
| OpenAI Compatible | Tergantung | ❌ | Custom |
| Ollama (Lokal) | ✅ Gratis | ✅ | Butuh HP kuat |

## Catatan Penting

- API Key disimpan lokal di HP, tidak dikirim ke server selain AI provider yang dipilih
- Accessibility Service hanya aktif saat ada task yang dijalankan
- Mode root opsional, sebagian besar fitur jalan tanpa root
